#Python Selenium (Pytest) Framework of BT Web Page :-
##To Check Various Functionalities:-

###Package Descriptions in Projects:-
- Driver :- In that Package Where Drivers are Stored for Project.
- Tests :- In that Package Where Tests.py File are Stored for Testing Different Scenarios.
- Util :- In that Package Where Config.py File are Stored for Used Repeated things in TestCase on One Time.
- ReadmeFile :- In that Package Where Like Architecture of Whole Project where we Write all the Uses and Functions.

###Test_Case Descriptions in Projects:-
- test_BT.py :- In that TestCase Where we Check Various Functionalities on BT web Page.
- conftest.py :- in that File Where Drivers SetUp and Quit Functionality are Used.


