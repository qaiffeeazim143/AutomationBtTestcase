driver_path="../Driver/chromedriver.exe"
otherDriver_path="../Driver/geckodriver.exe"
url="https://www.bt.com/"
browser_name="headless_chrome"